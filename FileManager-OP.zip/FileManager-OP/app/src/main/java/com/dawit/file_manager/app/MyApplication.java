package com.dawit.file_manager.app;

import android.app.Application;

public class MyApplication extends Application {

    public static String TAG = "MyApplication";

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
